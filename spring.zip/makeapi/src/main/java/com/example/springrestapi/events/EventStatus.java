package com.example.springrestapi.events;

public class EventStatus {
}
