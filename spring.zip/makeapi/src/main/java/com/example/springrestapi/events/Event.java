package com.example.springrestapi.events;

public class Event {
}
