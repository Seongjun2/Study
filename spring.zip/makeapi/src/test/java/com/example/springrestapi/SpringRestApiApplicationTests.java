package com.example.springrestapi;

import com.example.springrestapi.events.Event;
import org.junit.Test;
import static org.assertj.core.api.Assertions.assertThat;


public class SpringRestApiApplicationTests {

    @Test
    public void builder(){
        Event event = Event.builder().name("Spring REST API").description("REST API development").build();
    }
}
